export * from "./img/index.js";
export * from "./slide/index.js";